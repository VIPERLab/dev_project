/**
 * Created by JetBrains WebStorm.
 * User: wangfeng
 * Date: 12-7-2
 * Time: 上午11:51
 */
{
    plugins:[
        {
            active:true,
            name:"凤凰新闻",
            apkPath:"http://m.ifeng.com/upload/74/IfengNewsV3_android2.2_v3.0.1_m.ifeng.com.apk",
            iconPath:"news.png",
            visible:true,
            largeIconPath:'news_large.png',
            logoPath:"logo_news.png",
            productId:"ifengnews",
            description:"凤凰新闻依托凤凰卫视、凤凰网独家新闻资讯优势，每天24小时精心呈现全方位新闻讯息。",
            supportRead:true,
            compatVersion:'3.2.0',
            intent:{
                packageName:"com.ifeng.news2",
                className:"com.ifeng.news2.activity.DetailActivity",
                action:"action.com.ifeng.news2.push"
            },
            channels:["all"]
        }
    ],
    currentVersion:"1.0.3"
}

